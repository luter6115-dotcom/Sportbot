import os
import asyncio
import logging
from datetime import datetime, timezone
import aiohttp
from telegram import Bot, Update
from telegram.ext import Application, CommandHandler, ContextTypes

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "7619806032:AAGgkSy7GYVkCfSwyrvaKfadFk8OdCSPngc")
ODDS_API_KEY = os.getenv("ODDS_API_KEY", "0ab2d0fb41df00b46851894320d8b371")
CHAT_ID = os.getenv("CHAT_ID", "")

SPORTS = [
    "soccer_epl",
    "soccer_spain_la_liga",
    "soccer_germany_bundesliga",
    "soccer_italy_serie_a",
    "soccer_uefa_champs_league",
    "basketball_nba",
    "icehockey_nhl",
    "tennis_atp_french_open",
    "tennis_wta_french_open",
]

SPORT_EMOJI = {
    "soccer": "⚽",
    "basketball": "🏀",
    "icehockey": "🏒",
    "tennis": "🎾",
}

results_log = {}  # store predictions: {event_id: {prediction, home, away, odds}}


def get_emoji(sport_key):
    for k, v in SPORT_EMOJI.items():
        if k in sport_key:
            return v
    return "🏆"


def predict(outcomes):
    """Simple prediction: pick lowest odds (favourite)"""
    if not outcomes:
        return None, None
    favourite = min(outcomes, key=lambda x: x["price"])
    confidence = "HIGH" if favourite["price"] < 1.7 else "MED" if favourite["price"] < 2.2 else "LOW"
    return favourite["name"], confidence


async def fetch_odds(session, sport):
    url = f"https://api.the-odds-api.com/v4/sports/{sport}/odds/"
    params = {
        "apiKey": ODDS_API_KEY,
        "regions": "eu",
        "markets": "h2h",
        "oddsFormat": "decimal",
    }
    try:
        async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=10)) as r:
            if r.status == 200:
                return await r.json()
    except Exception as e:
        logger.error(f"Error fetching {sport}: {e}")
    return []


async def get_all_events():
    async with aiohttp.ClientSession() as session:
        tasks = [fetch_odds(session, s) for s in SPORTS]
        results = await asyncio.gather(*tasks)
    events = []
    for r in results:
        if isinstance(r, list):
            events.extend(r)
    return events


def format_event_message(event):
    emoji = get_emoji(event.get("sport_key", ""))
    home = event["home_team"]
    away = event["away_team"]
    sport_title = event.get("sport_title", event.get("sport_key", ""))
    commence = datetime.fromisoformat(event["commence_time"].replace("Z", "+00:00"))
    now = datetime.now(timezone.utc)
    is_live = commence < now

    time_str = "🔴 ЛАЙВ" if is_live else commence.strftime("%d.%m %H:%M")

    bookmakers = event.get("bookmakers", [])
    if not bookmakers:
        return None

    # Collect best odds
    best = {}
    for bk in bookmakers:
        for market in bk.get("markets", []):
            if market["key"] == "h2h":
                for o in market["outcomes"]:
                    if o["name"] not in best or o["price"] > best[o["name"]]:
                        best[o["name"]] = o["price"]

    outcomes = [{"name": k, "price": v} for k, v in best.items()]
    prediction, confidence = predict(outcomes)

    # Save to log
    results_log[event["id"]] = {
        "home": home,
        "away": away,
        "prediction": prediction,
        "time": commence,
        "sport": sport_title,
        "odds": best,
    }

    conf_icon = {"HIGH": "🟢", "MED": "🟡", "LOW": "🔴"}.get(confidence, "⚪")

    odds_str = " | ".join([f"{k}: {v:.2f}" for k, v in best.items()])
    msg = (
        f"{emoji} *{sport_title}*\n"
        f"🏠 {home} vs {away} ✈️\n"
        f"⏰ {time_str}\n"
        f"📊 КФ: {odds_str}\n"
        f"🎯 Прогноз: *{prediction}* {conf_icon} ({confidence})\n"
    )
    return msg


async def send_predictions(bot, chat_id):
    events = await get_all_events()
    if not events:
        await bot.send_message(chat_id=chat_id, text="⚠️ Нет данных от API")
        return

    now = datetime.now(timezone.utc)
    # Filter: upcoming in next 3h + live
    upcoming = []
    for e in events:
        try:
            t = datetime.fromisoformat(e["commence_time"].replace("Z", "+00:00"))
            diff = (t - now).total_seconds()
            if -7200 < diff < 10800:  # live or starting in 3h
                upcoming.append(e)
        except Exception:
            pass

    if not upcoming:
        await bot.send_message(chat_id=chat_id, text="📭 Нет ближайших матчей (лайв или старт в 3 часа)")
        return

    header = f"⚡ *ПРОГНОЗЫ* — {now.strftime('%d.%m %H:%M')} UTC\n{'─'*30}\n"
    await bot.send_message(chat_id=chat_id, text=header, parse_mode="Markdown")

    for event in upcoming[:15]:
        msg = format_event_message(event)
        if msg:
            try:
                await bot.send_message(chat_id=chat_id, text=msg, parse_mode="Markdown")
                await asyncio.sleep(0.3)
            except Exception as e:
                logger.error(f"Send error: {e}")


async def send_results(bot, chat_id):
    """Check finished matches and report results"""
    if not results_log:
        await bot.send_message(chat_id=chat_id, text="📋 Нет сохранённых прогнозов для проверки")
        return

    now = datetime.now(timezone.utc)
    finished = {k: v for k, v in results_log.items()
                if (now - v["time"]).total_seconds() > 7200}

    if not finished:
        await bot.send_message(chat_id=chat_id, text="⏳ Матчи ещё не завершились")
        return

    msg = "📋 *РЕЗУЛЬТАТЫ ПРОГНОЗОВ*\n\n"
    msg += "```\n"
    msg += f"{'Матч':<30} {'Прогноз':<20} {'Статус'}\n"
    msg += "─" * 60 + "\n"
    for k, v in finished.items():
        match = f"{v['home']} vs {v['away']}"[:28]
        pred = v['prediction'][:18] if v['prediction'] else "—"
        status = "✅ Проверено" if v.get("result") else "⏰ Ожидание"
        msg += f"{match:<30} {pred:<20} {status}\n"
    msg += "```"

    await bot.send_message(chat_id=chat_id, text=msg, parse_mode="Markdown")


# ─── COMMANDS ───────────────────────────────────────────────

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    # Save chat_id to env for scheduler
    os.environ["CHAT_ID"] = str(chat_id)
    with open("chat_id.txt", "w") as f:
        f.write(str(chat_id))
    await update.message.reply_text(
        "⚡ *SportRadar Bot запущен!*\n\n"
        "Команды:\n"
        "/now — прогнозы прямо сейчас\n"
        "/results — таблица результатов\n"
        "/stop — остановить авторассылку\n\n"
        "Авторассылка каждые *2 часа* 🔄",
        parse_mode="Markdown"
    )
    await send_predictions(context.bot, chat_id)


async def cmd_now(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    await update.message.reply_text("🔄 Загружаю матчи...")
    await send_predictions(context.bot, chat_id)


async def cmd_results(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    await send_results(context.bot, chat_id)


async def cmd_stop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("⛔ Авторассылка остановлена. Напиши /start чтобы возобновить.")


# ─── SCHEDULER ──────────────────────────────────────────────

async def scheduler(app):
    while True:
        await asyncio.sleep(7200)  # every 2 hours
        try:
            chat_id_file = "chat_id.txt"
            if os.path.exists(chat_id_file):
                with open(chat_id_file) as f:
                    cid = f.read().strip()
                if cid:
                    await send_predictions(app.bot, cid)
        except Exception as e:
            logger.error(f"Scheduler error: {e}")


async def post_init(app):
    asyncio.create_task(scheduler(app))


def main():
    app = Application.builder().token(TELEGRAM_TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("now", cmd_now))
    app.add_handler(CommandHandler("results", cmd_results))
    app.add_handler(CommandHandler("stop", cmd_stop))
    logger.info("Bot started!")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
